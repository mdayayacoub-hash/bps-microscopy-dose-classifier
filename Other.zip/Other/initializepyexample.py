import pandas as pd

df = pd.read_csv("meta.csv")
print(df.columns)
print(df.head())
