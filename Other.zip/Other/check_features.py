import pandas as pd

df = pd.read_csv("damage_features.csv")
print(df[["mean_brightness", "bright_fraction", "max_pixel_value"]].describe())
print("\nTop 10 bright_fraction:")
print(df.sort_values("bright_fraction", ascending=False)[["filename","particle_type","dose_Gy","bright_fraction"]].head(10))
