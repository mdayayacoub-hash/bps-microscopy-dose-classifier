import pandas as pd
import numpy as np
from PIL import Image

df = pd.read_csv("meta.csv")

# take first row
row = df.iloc[0]
filename = row["filename"]

# find the file in subfolders (simple search)
import os

image_path = None
for root, dirs, files in os.walk("train"):
    if filename in files:
        image_path = os.path.join(root, filename)
        break

print("Found image at:", image_path)

img = Image.open(image_path).convert("L")
arr = np.array(img) / 255.0

damage_score = (arr > 0.75).mean()

print("Particle type:", row["particle_type"])
print("Dose (Gy):", row["dose_Gy"])
print("Damage score:", damage_score)
