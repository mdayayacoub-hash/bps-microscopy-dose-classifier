import os
import pandas as pd
import numpy as np
import cv2

df = pd.read_csv("meta.csv")

# Pick a high dose example
df = df[df["dose_Gy"] >= 0.82].copy()

# Build map
file_map = {}
for root, _, files in os.walk("train"):
    for f in files:
        if f.lower().endswith(".tif") or f.lower().endswith(".tiff"):
            file_map[f] = os.path.join(root, f)

row = df.sample(1, random_state=2).iloc[0]
path = file_map[row["filename"]]

img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
if len(img.shape) == 3:
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
img = img.astype(np.float32)
img = img / img.max() if img.max() > 0 else img

kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
opened = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
tophat = img - opened

cv2.imwrite("highdose_original.png", (img * 255).astype(np.uint8))
cv2.imwrite("highdose_tophat.png", (tophat / (tophat.max() + 1e-8) * 255).astype(np.uint8))

print("Saved highdose_original.png and highdose_tophat.png")
print("Label:", row["particle_type"], "Dose:", row["dose_Gy"], "Hr:", row["hr_post_exposure"])
print("File:", row["filename"])
