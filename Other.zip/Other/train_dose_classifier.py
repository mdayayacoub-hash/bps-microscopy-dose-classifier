import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix

df = pd.read_csv("foci_features.csv")

# Keep only clearly separated doses
df = df[(df["dose_Gy"] <= 0.30) | (df["dose_Gy"] >= 0.82)].copy()

# Binary label: high dose = 1
y = (df["dose_Gy"] >= 0.82).astype(int)
X = df[["foci_mean", "foci_max", "foci_count"]]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

model = LogisticRegression(max_iter=2000, class_weight="balanced")
model.fit(X_train, y_train)

pred = model.predict(X_test)

print("Rows used:", len(df))
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print("\nReport:\n", classification_report(y_test, pred, target_names=["Low dose", "High dose"]))
