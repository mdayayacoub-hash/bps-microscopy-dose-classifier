import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("foci_features.csv")
df["damage_score"] = df["foci_count"] * df["foci_mean"]

plt.figure()
plt.scatter(df["dose_Gy"], df["damage_score"])
plt.xlabel("Dose (Gy)")
plt.ylabel("Damage score (foci_count * foci_mean)")
plt.title("DNA damage proxy vs radiation dose")
plt.savefig("damage_score_vs_dose.png", dpi=200, bbox_inches="tight")
plt.show()

print("Saved damage_score_vs_dose.png")
