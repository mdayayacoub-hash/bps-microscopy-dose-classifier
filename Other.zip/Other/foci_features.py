import os
import pandas as pd
import numpy as np
import cv2
from skimage.feature import blob_log

df = pd.read_csv("meta.csv")

# Map filenames to full paths
file_map = {}
for root, _, files in os.walk("train"):
    for f in files:
        if f.lower().endswith(".tif") or f.lower().endswith(".tiff"):
            file_map[f] = os.path.join(root, f)

def load_gray(path):
    # cv2.imread keeps 8-bit for many TIFFs; IMREAD_UNCHANGED can keep 16-bit if present
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise ValueError(f"Could not read {path}")
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img = img.astype(np.float32)

    # normalize to 0..1 robustly
    maxv = img.max()
    if maxv > 0:
        img = img / maxv
    return img

def compute_foci_features(img01):
    # Enhance small bright spots (foci) using white top-hat
    # Kernel size: adjust if needed (start with 15)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    opened = cv2.morphologyEx(img01, cv2.MORPH_OPEN, kernel)
    tophat = img01 - opened

    # Simple summary features
    foci_intensity_mean = float(tophat.mean())
    foci_intensity_max = float(tophat.max())

    # Blob detection: approximate count of bright puncta
    # min_sigma/max_sigma tune size of spots; threshold tunes sensitivity
    blobs = blob_log(tophat, min_sigma=1, max_sigma=4, num_sigma=4, threshold=0.03)
    foci_count = int(len(blobs))

    return foci_intensity_mean, foci_intensity_max, foci_count

# Process small subset first
N = 300
rows = []

for _, r in df.sample(N, random_state=42).iterrows():
    fname = r["filename"]
    path = file_map.get(fname)
    if not path:
        continue

    img01 = load_gray(path)
    mean_i, max_i, count = compute_foci_features(img01)

    rows.append({
        "filename": fname,
        "particle_type": r["particle_type"],
        "dose_Gy": r["dose_Gy"],
        "hr_post_exposure": r["hr_post_exposure"],
        "foci_mean": mean_i,
        "foci_max": max_i,
        "foci_count": count
    })

out = pd.DataFrame(rows)
out.to_csv("foci_features.csv", index=False)
print(out.head())
print("\nSummary:\n", out[["foci_mean","foci_max","foci_count"]].describe())
