import os
import pandas as pd
import numpy as np
from PIL import Image

# 1) Load metadata
df = pd.read_csv("meta.csv")

# 2) Build a filename -> full path map (fast lookup)
file_map = {}
for root, _, files in os.walk("train"):
    for f in files:
        if f.lower().endswith(".tif") or f.lower().endswith(".tiff"):
            file_map[f] = os.path.join(root, f)

print("Images found on disk:", len(file_map))
print("Rows in meta.csv:", len(df))

def compute_damage_features(img_path):
    img = Image.open(img_path).convert("L")
    arr = np.array(img)

    # Robust normalization for 8-bit OR 16-bit images
    maxv = arr.max()
    if maxv == 0:
        arr_norm = arr.astype(np.float32)
    else:
        arr_norm = arr.astype(np.float32) / float(maxv)

    mean_brightness = float(arr_norm.mean())
    std_brightness = float(arr_norm.std())
    bright_fraction = float((arr_norm > 0.75).mean())  # adjust later if needed

    return mean_brightness, std_brightness, bright_fraction, int(maxv)

# 3) Process a small subset first (so it runs fast)
N = 500  # change to 2000 later when you're confident
rows = []

missing = 0
for i, r in df.head(N).iterrows():
    fname = r["filename"]
    path = file_map.get(fname)

    if path is None:
        missing += 1
        continue

    mean_b, std_b, bright_frac, maxv = compute_damage_features(path)

    rows.append({
        "filename": fname,
        "particle_type": r["particle_type"],
        "dose_Gy": r["dose_Gy"],
        "hr_post_exposure": r["hr_post_exposure"],
        "mean_brightness": mean_b,
        "std_brightness": std_b,
        "bright_fraction": bright_frac,
        "max_pixel_value": maxv
    })

out = pd.DataFrame(rows)
out.to_csv("damage_features.csv", index=False)

print("Saved:", "damage_features.csv")
print("Processed:", len(out), "images")
print("Missing files:", missing)
print(out.head())
