from PIL import Image
import matplotlib.pyplot as plt

img = Image.open("train/P242_73665006707-A6_001_009_proj.tif")
plt.imshow(img, cmap="gray")
plt.title("Example image")
plt.axis("off")
plt.show()
